
这个自述文件介绍了如何在quecpython中使用esp8266 slip。

cat1+esp8266采用串口连接，通过slip协议进行网络传输。

文件描述：
	ESP8266_SLIP_X26M_BETA20240301.bin  --esp8266固件，需要烧录到esp8266上。
	WLAN.py  --导入到quecpython 文件系统usr目录，用于控制wifi，比如联网，状态查询等。

应用指导链接:
	https://python.quectel.com/doc/Application_guide/zh/network-comm/nic/index.html

wiki介绍链接：
	https://python.quectel.com/doc/API_reference/zh/wifilib/WLAN.ESP8266.html
