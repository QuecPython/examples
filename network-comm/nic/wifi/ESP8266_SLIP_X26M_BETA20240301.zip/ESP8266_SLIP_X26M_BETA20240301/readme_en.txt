
This readme introduce esp8266 slip how to use in quecpython.

cat1+esp8266 uses serial port connection and network transmission through slip protocol.

File description:
	ESP8266_SLIP_X26M_BETA20240301.bin  --esp8266 firmware, need to burn to the esp8266
	WLAN.py --Imported into quecpython file system usr directory, used to control wifi, such as networking, status query, etc.

guide link: 
	https://python.quectel.com/doc/Application_guide/en/network-comm/nic/index.html

wiki link:
	https://python.quectel.com/doc/API_reference/en/wifilib/WLAN.ESP8266.html