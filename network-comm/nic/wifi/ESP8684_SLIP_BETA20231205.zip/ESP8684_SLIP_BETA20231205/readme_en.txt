
This readme introduce esp8684 slip how to use in quecpython.

cat1+esp8684 uses serial port connection and network transmission through slip protocol.

File description:
	ESP8684_SLIP_BETA20231205.bin  --esp8684 firmware, need to burn to the esp8684
	WLAN.py --Imported into quecpython file system usr directory, used to control wifi, such as networking, status query, etc.

guide link: 
	https://python.quectel.com/doc/Application_guide/en/network-comm/nic/index.html

wiki link:
	https://python.quectel.com/doc/API_reference/en/wifilib/WLAN.ESP8266.html