
这个自述文件介绍了如何在quecpython中使用esp8684 slip。

cat1+esp8684采用串口连接，通过slip协议进行网络传输。

文件描述：
	ESP8684_SLIP_BETA20231205.bin  --esp8684固件，需要烧录到esp8684上。
	WLAN.py  --导入到quecpython 文件系统usr目录，用于控制wifi，比如联网，状态查询等。

应用指导链接:
	https://python.quectel.com/doc/Application_guide/zh/network-comm/nic/index.html

wiki介绍链接：
	https://python.quectel.com/doc/API_reference/zh/wifilib/WLAN.ESP8266.html
