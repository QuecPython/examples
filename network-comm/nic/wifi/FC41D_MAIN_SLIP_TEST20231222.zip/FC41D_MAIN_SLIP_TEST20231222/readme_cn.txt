
这个自述文件介绍了如何在quecpython中使用FC41D slip。

1. 将FC41D_MAIN_SLIP_TEST20231222.bin文件烧到FC41D设备上，用以支持slip协议。

2. 将WLAN.py文件拖动到quecpython文件系统中。然后运行“from usr.WLAN import FC41D”

3. 现在，你可以按照quecpython的esp8266函数来使用它。

应用指导链接:
	https://python.quectel.com/doc/Application_guide/zh/network-comm/nic/wifi/wifi-station-example.html
wiki链接：
	https://python.quectel.com/doc/API_reference/zh/wifilib/WLAN.ESP8266.html

更新日志：
1. 增加web配网功能。
2. 增加了airkiss配网功能。
