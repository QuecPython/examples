
This readme introduce FC41D slip how to use in quecpython.

1. burn FC41D_MAIN_SLIP_TEST20231222.bin file to FC41D device, to surport slip protocol.

2. Drag files WLAN.py into the quecpython filesystem. and run 'from usr.WLAN import FC41D'.

3. now,you can follow quecpython esp8266 function to use it.

guide link: 
	https://python.quectel.com/doc/Application_guide/en/network-comm/nic/wifi/wifi-station-example.html

wiki link: 
	https://python.quectel.com/doc/API_reference/en/wifilib/WLAN.ESP8266.html

changelog:
1. Added web network configuration.
2. Added airkiss network configuration.
